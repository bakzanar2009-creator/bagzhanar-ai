import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || "*" }));
app.use(express.json({ limit: "1mb" }));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: true, legacyHeaders: false }));

if (!process.env.OPENAI_API_KEY) console.warn("OPENAI_API_KEY жоқ: /api/chat сұраулары жұмыс істемейді.");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.get("/health", (_req, res) => res.json({ ok: true, app: "BAGZHANAR AI" }));

app.post("/api/chat", async (req, res) => {
  try {
    const messages = req.body?.messages;
    if (!Array.isArray(messages) || messages.length < 1 || messages.length > 50) {
      return res.status(400).json({ error: "INVALID_MESSAGES" });
    }
    const clean = [];
    for (const m of messages) {
      if (!m || !["user", "assistant"].includes(m.role) || typeof m.content !== "string" ||
          !m.content.trim() || m.content.length > 12000) {
        return res.status(400).json({ error: "INVALID_MESSAGE" });
      }
      clean.push({ role: m.role, content: m.content.trim() });
    }
    const completion = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages: [
        { role: "system", content: "Сен BAGZHANAR AI атты пайдалы жеке көмекшісің. Әдепкіде қазақ тілінде жауап бер, бірақ пайдаланушы басқа тілде жазса, сол тілде жауап бер. Оқушыға тапсырманы қадам-қадамымен түсіндір. Нақты білмесең, ойдан қоспа." },
        ...clean
      ],
      temperature: 0.7
    });
    const reply = completion.choices?.[0]?.message?.content;
    if (!reply) return res.status(502).json({ error: "EMPTY_AI_RESPONSE" });
    res.json({ reply });
  } catch (e) {
    console.error("AI request failed:", e?.status || e?.name || "unknown");
    if (e?.status === 429) return res.status(429).json({ error: "RATE_LIMIT" });
    res.status(502).json({ error: "AI_UNAVAILABLE" });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`BAGZHANAR AI backend listening on ${port}`));
